ALTER TABLE `dict_column` ADD `noaudit` VARCHAR( 3 ) AFTER `nosearch` ;
