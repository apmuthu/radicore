ALTER TABLE `dict_column` ADD `checkbox_label` VARCHAR( 64 ) NULL AFTER `optionlist` ;

ALTER TABLE `dict_column` ADD `align_lr` CHAR( 1 ) NULL AFTER `align_hv` ;
