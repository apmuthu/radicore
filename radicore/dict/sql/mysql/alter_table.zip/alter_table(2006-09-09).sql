ALTER TABLE `dict_column` ADD `custom_validation` VARCHAR( 255 ) NULL AFTER `multi_rows` ;
