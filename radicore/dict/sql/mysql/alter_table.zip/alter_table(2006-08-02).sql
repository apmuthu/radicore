ALTER TABLE `dict_column` ADD `col_array_type` VARCHAR( 12 ) NULL AFTER `col_type` ;
