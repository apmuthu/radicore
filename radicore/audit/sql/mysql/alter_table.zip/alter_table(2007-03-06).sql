ALTER TABLE `audit_trn` CHANGE `task_id` `task_id` VARCHAR( 80 ) NOT NULL;
