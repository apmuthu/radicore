ALTER TABLE `audit_fld` TYPE = innodb;
ALTER TABLE `audit_ssn` TYPE = innodb;
ALTER TABLE `audit_tbl` TYPE = innodb;
ALTER TABLE `audit_trn` TYPE = innodb;
