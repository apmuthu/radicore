ALTER TABLE `wf_transition` CHANGE `role_id` `role_id` VARCHAR( 16 ) NULL 

