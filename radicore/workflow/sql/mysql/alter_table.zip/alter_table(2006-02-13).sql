ALTER TABLE `wf_transition` CHANGE `time_limit` `time_limit` SMALLINT UNSIGNED NULL DEFAULT NULL 
