ALTER TABLE menu.mnu_initial_value_role ALTER initial_value TYPE character varying(255);
ALTER TABLE menu.mnu_initial_value_user ALTER initial_value TYPE character varying(255);
