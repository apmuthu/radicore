UPDATE `mnu_task` SET `max_execution_time`='120' ,`revised_date`='2012-07-15 14:20:19' ,`revised_user`='AJM' WHERE task_id='mnu_subsystem(erase)';
