-- USE `menu`;

UPDATE `mnu_task` SET `revised_date`='2014-05-04 05:58:16' ,`revised_user`='AJM' ,`task_desc`='Add User Role' WHERE task_id='mnu_user_role(add2)';
UPDATE `mnu_task` SET `revised_date`='2014-05-04 05:58:25' ,`revised_user`='AJM' ,`task_desc`='Delete User Role' WHERE task_id='mnu_user_role(del1)';
UPDATE `mnu_task` SET `revised_date`='2014-05-04 05:58:32' ,`revised_user`='AJM' ,`task_desc`='Enquire User Role' WHERE task_id='mnu_user_role(enq1)';
UPDATE `mnu_task` SET `revised_date`='2014-05-04 05:58:40' ,`revised_user`='AJM' ,`task_desc`='Search User Role' WHERE task_id='mnu_user_role(search)';
UPDATE `mnu_task` SET `revised_date`='2014-05-04 05:58:48' ,`revised_user`='AJM' ,`task_desc`='Update User Role' WHERE task_id='mnu_user_role(upd1)';
