
use `menu`;

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:15:17' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(add3)' WHERE task_id_snr='mnu_nav_button(list)' AND task_id_jnr='mnu_nav_button(add)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:15:17' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(add3)' WHERE task_id_snr='mnu_nav_button(maint)' AND task_id_jnr='mnu_nav_button(add)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:15:17' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(add3)' WHERE task_id_snr='mnu_nav_button(multi)' AND task_id_jnr='mnu_nav_button(add)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 11:15:18' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(add3)' WHERE task_id='mnu_nav_button(add)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:15:43' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(del2)' WHERE task_id_snr='mnu_nav_button(list)' AND task_id_jnr='mnu_nav_button(del)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:15:43' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(del2)' WHERE task_id_snr='mnu_nav_button(maint)' AND task_id_jnr='mnu_nav_button(del)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:15:43' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(del2)' WHERE task_id_snr='mnu_nav_button(multi)' AND task_id_jnr='mnu_nav_button(del)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 11:15:43' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(del2)' WHERE task_id='mnu_nav_button(del)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' WHERE task_id='mnu_nav_button(list)';

UPDATE `help_text` SET `revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(list2)' WHERE task_id='mnu_nav_button(list)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(list2)' WHERE task_id_snr='mnu_nav_button(list)' AND task_id_jnr='mnu_nav_button(add3)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(list2)' WHERE task_id_snr='mnu_nav_button(list)' AND task_id_jnr='mnu_nav_button(upd)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(list2)' WHERE task_id_snr='mnu_nav_button(list)' AND task_id_jnr='mnu_nav_button(del2)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(list2)' WHERE task_id_snr='mnu_nav_button(list)' AND task_id_jnr='mnu_nav_button(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(list2)' WHERE task_id_snr='mnu_nav_button(list)' AND task_id_jnr='audit_dtl(list)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:12' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(list2)' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_nav_button(list)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:13' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(list2)' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_nav_button(list)';

UPDATE `mnu_role_task` SET `revised_date`='2007-08-12 11:16:13' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(list2)' WHERE role_id='DEMO' AND task_id='mnu_nav_button(list)';

UPDATE `mnu_role_task` SET `revised_date`='2007-08-12 11:16:13' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(list2)' WHERE role_id='READONLY' AND task_id='mnu_nav_button(list)';

UPDATE `mnu_role_task` SET `revised_date`='2007-08-12 11:16:13' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(list2)' WHERE role_id='SURVEY' AND task_id='mnu_nav_button(list)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 11:16:13' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(list2)' WHERE task_id='mnu_nav_button(list)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 11:16:39' ,`revised_user`='AJM' WHERE task_id='mnu_nav_button(link)';

UPDATE `help_text` SET `revised_date`='2007-08-12 11:16:40' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(link1)' WHERE task_id='mnu_nav_button(link)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:40' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(link1)' WHERE task_id_snr='mnu_nav_button(link)' AND task_id_jnr='mnu_task(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:40' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(link1)' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_nav_button(link)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:16:40' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(link1)' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_nav_button(link)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 11:16:40' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(link1)' WHERE task_id='mnu_nav_button(link)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 11:17:09' ,`revised_user`='AJM' WHERE task_id='mnu_nav_button(multi)';

UPDATE `help_text` SET `revised_date`='2007-08-12 11:17:10' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(multi2)' WHERE task_id='mnu_nav_button(multi)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:17:10' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(multi2)' WHERE task_id_snr='mnu_nav_button(multi)' AND task_id_jnr='mnu_nav_button(add3)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:17:10' ,`revised_user`='AJM' ,`task_id_snr`='mnu_nav_button(multi2)' WHERE task_id_snr='mnu_nav_button(multi)' AND task_id_jnr='mnu_nav_button(del2)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:17:10' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(multi2)' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_nav_button(multi)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:17:10' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(multi2)' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_nav_button(multi)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 11:17:10' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(multi2)' WHERE task_id='mnu_nav_button(multi)';

UPDATE `help_text` SET `revised_date`='2007-08-12 11:18:58' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(upd1)' WHERE task_id='mnu_nav_button(upd)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:18:58' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_nav_button(upd1)' WHERE task_id_snr='mnu_nav_button(list2)' AND task_id_jnr='mnu_nav_button(upd)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 11:18:58' ,`revised_user`='AJM' ,`task_id`='mnu_nav_button(upd1)' WHERE task_id='mnu_nav_button(upd)';

REPLACE INTO `mnu_task` (`button_text` ,`created_date` ,`created_user` ,`is_disabled` ,`keep_data` ,`log_sql_query` ,`pattern_id` ,`script_id` ,`subsys_id` ,`task_desc` ,`task_id` ,`task_type` ,`use_https`) VALUES
('Navigation Button' ,'2007-08-12 11:25:09' ,'AJM' ,'N' ,'N' ,'N' ,'LIST2' ,'mnu_nav_button(list2).php' ,'MENU' ,'List mnu_nav_button by mnu_task' ,'mnu_nav_button(list2)a' ,'PROC' ,'N');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('New' ,'N' ,'2007-08-12 11:25:09' ,'AJM' ,'001' ,'mnu_nav_button(add3)' ,'mnu_nav_button(list2)a');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Delete' ,'Y' ,'2007-08-12 11:25:09' ,'AJM' ,'002' ,'mnu_nav_button(del2)' ,'mnu_nav_button(list2)a');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Search' ,'N' ,'2007-08-12 11:25:09' ,'AJM' ,'003' ,'mnu_nav_button(search)' ,'mnu_nav_button(list2)a');

UPDATE `mnu_task` SET `button_text`='Navigation Button (Parents)' ,`revised_date`='2007-08-12 11:27:28' ,`revised_user`='AJM' ,`task_desc`='List Navigation Button parents' WHERE task_id='mnu_nav_button(list2)a';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 11:27:41' ,`revised_user`='AJM' ,`task_desc`='List Navigation Button Parents' WHERE task_id='mnu_nav_button(list2)a';

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Navigation Button (Parents)' ,'Y' ,'2007-08-12 11:29:07' ,'AJM' ,'020' ,'mnu_nav_button(list2)a' ,'mnu_task(list)a');

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='011' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task_field(list)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='012' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_role_taskfield(multi)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='013' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_initial_value_role(multi3)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='014' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_initial_value_user(multi3)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='015' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(rename)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='016' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='017' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(pdf)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='018' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(pdf)2';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:52' ,`revised_user`='AJM' ,`sort_seq`='019' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(pdf)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:53' ,`revised_user`='AJM' ,`sort_seq`='020' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='audit_dtl(list)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 11:29:53' ,`revised_user`='AJM' ,`sort_seq`='010' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_nav_button(list2)a';

REPLACE INTO `mnu_task` (`button_text` ,`created_date` ,`created_user` ,`is_disabled` ,`keep_data` ,`log_sql_query` ,`pattern_id` ,`script_id` ,`subsys_id` ,`task_desc` ,`task_id` ,`task_type` ,`use_https`) VALUES
('Insert' ,'2007-08-12 13:42:22' ,'AJM' ,'N' ,'N' ,'N' ,'ADD3' ,'mnu_nav_button(add3)a.php' ,'MENU' ,'Add Navigation Button' ,'mnu_nav_button(add3)a' ,'PROC' ,'N');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Insert' ,'N' ,'2007-08-12 13:42:50' ,'AJM' ,'004' ,'mnu_nav_button(add3)a' ,'mnu_nav_button(list2)a');

DELETE FROM `mnu_nav_button` WHERE task_id_snr='mnu_nav_button(list2)a' AND task_id_jnr='mnu_nav_button(add3)';

UPDATE `mnu_nav_button` SET `button_text`='New' ,`revised_date`='2007-08-12 13:43:27' ,`revised_user`='AJM' ,`sort_seq`='013' WHERE task_id_snr='mnu_nav_button(list2)a' AND task_id_jnr='mnu_nav_button(add3)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 13:45:56' ,`revised_user`='AJM' ,`sort_seq`='001' WHERE task_id_snr='mnu_nav_button(list2)a' AND task_id_jnr='mnu_nav_button(add3)a';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 14:19:06' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(add3).php' WHERE task_id='mnu_nav_button(add3)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 14:19:56' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(del2).php' WHERE task_id='mnu_nav_button(del2)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 14:20:37' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(link1).php' WHERE task_id='mnu_nav_button(link1)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 14:22:09' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(list2).php' WHERE task_id='mnu_nav_button(list2)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 14:22:28' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(list2)a.php' WHERE task_id='mnu_nav_button(list2)a';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 14:22:57' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(multi2).php' WHERE task_id='mnu_nav_button(multi2)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 14:23:47' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(search).php' WHERE task_id='mnu_nav_button(search)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 14:24:14' ,`revised_user`='AJM' ,`script_id`='mnu_nav_button(upd1).php' WHERE task_id='mnu_nav_button(upd1)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 17:25:17' ,`revised_user`='AJM' ,`script_id`='mnu_menu(add3).php' WHERE task_id='mnu_menu(add)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:25:52' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(add3)' WHERE task_id_snr='mnu_menu(list)' AND task_id_jnr='mnu_menu(add)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:25:52' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(add3)' WHERE task_id_snr='mnu_menu(multi)' AND task_id_jnr='mnu_menu(add)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 17:25:55' ,`revised_user`='AJM' ,`task_id`='mnu_menu(add3)' WHERE task_id='mnu_menu(add)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 17:26:29' ,`revised_user`='AJM' ,`script_id`='mnu_menu(del2).php' WHERE task_id='mnu_menu(del)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:26:51' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(del2)' WHERE task_id_snr='mnu_menu(list)' AND task_id_jnr='mnu_menu(del)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:26:51' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(del2)' WHERE task_id_snr='mnu_menu(multi)' AND task_id_jnr='mnu_menu(del)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 17:26:52' ,`revised_user`='AJM' ,`task_id`='mnu_menu(del2)' WHERE task_id='mnu_menu(del)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 17:27:46' ,`revised_user`='AJM' ,`script_id`='mnu_menu(link1).php' WHERE task_id='mnu_menu(link)';

UPDATE `help_text` SET `revised_date`='2007-08-12 17:28:00' ,`revised_user`='AJM' ,`task_id`='mnu_menu(link1)' WHERE task_id='mnu_menu(link)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:00' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(link1)' WHERE task_id_snr='mnu_menu(link)' AND task_id_jnr='mnu_task(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:00' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(link1)' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_menu(link)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:00' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(link1)' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_menu(link)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 17:28:00' ,`revised_user`='AJM' ,`task_id`='mnu_menu(link1)' WHERE task_id='mnu_menu(link)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 17:28:34' ,`revised_user`='AJM' ,`script_id`='mnu_menu(list2).php' WHERE task_id='mnu_menu(list)';

UPDATE `help_text` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id`='mnu_menu(list2)' WHERE task_id='mnu_menu(list)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(list2)' WHERE task_id_snr='mnu_menu(list)' AND task_id_jnr='mnu_menu(add3)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(list2)' WHERE task_id_snr='mnu_menu(list)' AND task_id_jnr='mnu_menu(upd)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(list2)' WHERE task_id_snr='mnu_menu(list)' AND task_id_jnr='mnu_menu(del2)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(list2)' WHERE task_id_snr='mnu_menu(list)' AND task_id_jnr='mnu_menu(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(list2)' WHERE task_id_snr='mnu_menu(list)' AND task_id_jnr='audit_dtl(list)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(list2)' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_menu(list)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(list2)' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_menu(list)';

UPDATE `mnu_role_task` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id`='mnu_menu(list2)' WHERE role_id='DEMO' AND task_id='mnu_menu(list)';

UPDATE `mnu_role_task` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id`='mnu_menu(list2)' WHERE role_id='READONLY' AND task_id='mnu_menu(list)';

UPDATE `mnu_role_task` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id`='mnu_menu(list2)' WHERE role_id='SURVEY' AND task_id='mnu_menu(list)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 17:28:50' ,`revised_user`='AJM' ,`task_id`='mnu_menu(list2)' WHERE task_id='mnu_menu(list)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 17:29:33' ,`revised_user`='AJM' ,`script_id`='mnu_menu(multi2).php' WHERE task_id='mnu_menu(multi)';

UPDATE `help_text` SET `revised_date`='2007-08-12 17:29:47' ,`revised_user`='AJM' ,`task_id`='mnu_menu(multi2)' WHERE task_id='mnu_menu(multi)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:29:47' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(multi2)' WHERE task_id_snr='mnu_menu(multi)' AND task_id_jnr='mnu_menu(add3)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:29:47' ,`revised_user`='AJM' ,`task_id_snr`='mnu_menu(multi2)' WHERE task_id_snr='mnu_menu(multi)' AND task_id_jnr='mnu_menu(del2)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:29:47' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(multi2)' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_menu(multi)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:29:47' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(multi2)' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_menu(multi)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 17:29:47' ,`revised_user`='AJM' ,`task_id`='mnu_menu(multi2)' WHERE task_id='mnu_menu(multi)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 17:30:19' ,`revised_user`='AJM' ,`script_id`='mnu_menu(search).php' WHERE task_id='mnu_menu(search)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2007-08-12 17:30:39' ,`revised_user`='AJM' ,`script_id`='mnu_menu(upd1).php' WHERE task_id='mnu_menu(upd)';

UPDATE `help_text` SET `revised_date`='2007-08-12 17:30:55' ,`revised_user`='AJM' ,`task_id`='mnu_menu(upd1)' WHERE task_id='mnu_menu(upd)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:30:55' ,`revised_user`='AJM' ,`task_id_jnr`='mnu_menu(upd1)' WHERE task_id_snr='mnu_menu(list2)' AND task_id_jnr='mnu_menu(upd)';

UPDATE `mnu_task` SET `revised_date`='2007-08-12 17:30:56' ,`revised_user`='AJM' ,`task_id`='mnu_menu(upd1)' WHERE task_id='mnu_menu(upd)';

REPLACE INTO `mnu_task` (`button_text` ,`created_date` ,`created_user` ,`is_disabled` ,`keep_data` ,`log_sql_query` ,`pattern_id` ,`script_id` ,`subsys_id` ,`task_desc` ,`task_id` ,`task_type` ,`use_https`) VALUES
('Menu' ,'2007-08-12 17:38:48' ,'AJM' ,'N' ,'N' ,'N' ,'LIST2' ,'mnu_menu(list2)a.php' ,'MENU' ,'List mnu_menu by mnu_task' ,'mnu_menu(list2)a' ,'PROC' ,'N');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('New' ,'N' ,'2007-08-12 17:38:48' ,'AJM' ,'001' ,'mnu_menu(add3)' ,'mnu_menu(list2)a');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Delete' ,'Y' ,'2007-08-12 17:38:48' ,'AJM' ,'002' ,'mnu_menu(del2)' ,'mnu_menu(list2)a');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Search' ,'N' ,'2007-08-12 17:38:48' ,'AJM' ,'003' ,'mnu_menu(search)' ,'mnu_menu(list2)a');

UPDATE `mnu_task` SET `button_text`='Menu (Parents)' ,`revised_date`='2007-08-12 17:40:21' ,`revised_user`='AJM' ,`task_desc`='List Menu Parents' WHERE task_id='mnu_menu(list2)a';

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Menu (Parents)' ,'Y' ,'2007-08-12 17:41:40' ,'AJM' ,'015' ,'mnu_menu(list2)a' ,'mnu_task(list)b');

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:42:02' ,`revised_user`='AJM' ,`sort_seq`='011' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_task(rename)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:42:03' ,`revised_user`='AJM' ,`sort_seq`='012' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_task(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:42:03' ,`revised_user`='AJM' ,`sort_seq`='013' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='audit_dtl(list)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:42:03' ,`revised_user`='AJM' ,`sort_seq`='014' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_task(pdf)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:42:03' ,`revised_user`='AJM' ,`sort_seq`='015' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_task(pdf)2';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 17:42:03' ,`revised_user`='AJM' ,`sort_seq`='010' WHERE task_id_snr='mnu_task(list)b' AND task_id_jnr='mnu_menu(list2)a';

REPLACE INTO `mnu_task` (`button_text` ,`created_date` ,`created_user` ,`is_disabled` ,`keep_data` ,`log_sql_query` ,`pattern_id` ,`script_id` ,`subsys_id` ,`task_desc` ,`task_id` ,`task_type` ,`use_https`) VALUES
('Insert' ,'2007-08-12 17:56:28' ,'AJM' ,'N' ,'N' ,'N' ,'ADD3' ,'mnu_menu(add3)a.php' ,'MENU' ,'Add Menu Items' ,'mnu_menu(add3)a' ,'PROC' ,'N');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Insert' ,'N' ,'2007-08-12 17:56:49' ,'AJM' ,'004' ,'mnu_menu(add3)a' ,'mnu_menu(list2)a');

DELETE FROM `mnu_nav_button` WHERE task_id_snr='mnu_menu(list2)a' AND task_id_jnr='mnu_menu(add3)';

UPDATE `mnu_nav_button` SET `button_text`='New' ,`revised_date`='2007-08-12 17:57:08' ,`revised_user`='AJM' ,`sort_seq`='001' WHERE task_id_snr='mnu_menu(list2)a' AND task_id_jnr='mnu_menu(add3)a';

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Menu (Parents)' ,'Y' ,'2007-08-12 18:08:29' ,'AJM' ,'021' ,'mnu_menu(list2)a' ,'mnu_task(list)a');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Menu (Parents)' ,'Y' ,'2007-08-12 18:08:29' ,'AJM' ,'021' ,'mnu_menu(list2)a' ,'mnu_task(list)a');

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='012' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task_field(list)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='013' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_role_taskfield(multi)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='014' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_initial_value_role(multi3)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='015' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_initial_value_user(multi3)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='016' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(rename)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='017' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='018' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(pdf)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='019' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(pdf)2';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='020' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_task(pdf)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='021' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='audit_dtl(list)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-12 18:09:12' ,`revised_user`='AJM' ,`sort_seq`='011' WHERE task_id_snr='mnu_task(list)a' AND task_id_jnr='mnu_menu(list2)a';

UPDATE `help_text` SET `help_text`='This will display the contents of the NAVIGATION BUTTON table for a selected Task. Each of these will appear in the navigation bar area for the seected task.

Refer to <a href=\"%root%/mnu_nav_button(link1).html\">Maintain Navigation Buttons (2)</a> for full details.' ,`revised_date`='2007-08-12 18:24:09' ,`revised_user`='AJM' WHERE task_id='mnu_nav_button(link1)';

UPDATE `help_text` SET `help_text`='This will list records on the NAVIGATION BUTTON table for a selected TASK.

Refer to <a href=\"%root%/mnu_nav_button(list2).html\">List Navigation Buttons</a> for full details.' ,`revised_date`='2007-08-12 18:25:12' ,`revised_user`='AJM' WHERE task_id='mnu_nav_button(list2)';

UPDATE `help_text` SET `help_text`='This will display the contents of the NAVIGATION BUTTON table for a selected task. 

Refer to <a href=\"%root%/mnu_nav_button(multi2).html\">Maintain Navigation Buttons (1)</a> for full details.' ,`revised_date`='2007-08-12 18:25:59' ,`revised_user`='AJM' WHERE task_id='mnu_nav_button(multi2)';

UPDATE `help_text` SET `help_text`='This will display the contents of a record from the NAVIGATION BUTTON table and allow it to be updated. 

Refer to <a href=\"%root%/mnu_nav_button(upd1).html\">Update Navigation Button</a> for full details.' ,`revised_date`='2007-08-12 18:26:40' ,`revised_user`='AJM' WHERE task_id='mnu_nav_button(upd1)';

REPLACE INTO `help_text` (`created_date` ,`created_user` ,`help_text` ,`task_id`) VALUES
('2007-08-12 18:27:39' ,'AJM' ,'This will list parent records on the NAVIGATION BUTTON table for a selected TASK.

Refer to <a href=\"%root%/mnu_nav_button(list2)a.html\">List Navigation Buttons</a> for full details.' ,'mnu_nav_button(list2)a');

UPDATE `mnu_nav_button` SET `button_text`='New' ,`revised_date`='2007-08-12 18:55:55' ,`revised_user`='AJM' WHERE task_id_snr='mnu_nav_button(list2)a' AND task_id_jnr='mnu_nav_button(add3)a';


REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Navigation Button (Parents)' ,'Y' ,'2007-08-13 10:16:50' ,'AJM' ,'023' ,'mnu_nav_button(list2)a' ,'mnu_task(list)');

REPLACE INTO `mnu_nav_button` (`button_text` ,`context_preselect` ,`created_date` ,`created_user` ,`sort_seq` ,`task_id_jnr` ,`task_id_snr`) VALUES
('Menu (Parents)' ,'Y' ,'2007-08-13 10:17:03' ,'AJM' ,'024' ,'mnu_menu(list2)a' ,'mnu_task(list)');

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:47' ,`revised_user`='AJM' ,`sort_seq`='011' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_menu(multi2)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:47' ,`revised_user`='AJM' ,`sort_seq`='012' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_menu(link1)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:47' ,`revised_user`='AJM' ,`sort_seq`='013' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_menu(list2)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:47' ,`revised_user`='AJM' ,`sort_seq`='015' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_task_field(list)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:47' ,`revised_user`='AJM' ,`sort_seq`='016' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_role_taskfield(multi)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:47' ,`revised_user`='AJM' ,`sort_seq`='017' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_initial_value_role(multi3)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='018' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_initial_value_user(multi3)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='019' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_task(rename)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='020' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_task(search)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='021' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_task(pdf)';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='022' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_task(pdf)2';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='023' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_task(pdf)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='024' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='audit_dtl(list)3';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='010' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_nav_button(list2)a';

UPDATE `mnu_nav_button` SET `revised_date`='2007-08-13 10:18:48' ,`revised_user`='AJM' ,`sort_seq`='014' WHERE task_id_snr='mnu_task(list)' AND task_id_jnr='mnu_menu(list2)a';
