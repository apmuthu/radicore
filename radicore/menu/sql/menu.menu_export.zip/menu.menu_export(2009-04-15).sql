USE `menu`;

UPDATE `mnu_task` SET `revised_date`='2009-04-15 15:52:56' ,`revised_user`='AJM' ,`settings`='download=FALSE' WHERE task_id='batch_log(filepicker)';
