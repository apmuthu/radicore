USE `menu`;

UPDATE `mnu_task` SET `revised_date`='2009-05-14 10:03:42' ,`revised_user`='AJM' ,`script_id`='mnu_pattern(enq1).php' WHERE task_id='mnu_pattern(enq1)';

UPDATE `mnu_task` SET `log_sql_query`='N' ,`revised_date`='2009-05-14 10:05:57' ,`revised_user`='AJM' ,`script_id`='mnu_role(search).php' WHERE task_id='mnu_role(search)';
