USE `menu`;

REPLACE INTO `mnu_pattern` (`context_preselect` ,`created_date` ,`created_user` ,`keep_data` ,`pattern_desc` ,`pattern_id` ,`pattern_long_desc` ,`visible_screen`) VALUES
('N' ,'2011-08-24 10:11:16' ,'AJM' ,'N' ,'OUTPUT5 - Output records to a PDF file (Address Labels)' ,'OUTPUT5' ,'This will extract all available rows from a database table and output them to a PDF file which will be downloaded to the client device.\r\n\r\nIt will use any search criteria that is passed down from the calling screen.\r\n\r\nLabel view constructs one label from each database record, then prints several labels across each line.' ,'N');
