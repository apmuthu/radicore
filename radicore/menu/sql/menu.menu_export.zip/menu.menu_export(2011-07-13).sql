USE `menu`;

UPDATE `mnu_task` SET `order_by`='role_id' ,`revised_date`='2011-07-13 11:35:00' ,`revised_user`='AJM' WHERE task_id='mnu_role_task(link1)a';
