USE `menu`;

UPDATE `mnu_task` SET `revised_date`='2008-11-27 12:23:57' ,`revised_user`='AJM' ,`screen_refresh`='10' WHERE task_id='batch_log(filepicker)';
