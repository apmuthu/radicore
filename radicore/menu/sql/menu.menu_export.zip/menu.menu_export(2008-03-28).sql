use `menu`;

REPLACE INTO `mnu_pattern` (`context_preselect` ,`created_date` ,`created_user` ,`keep_data` ,`pattern_desc` ,`pattern_id` ,`pattern_long_desc` ,`visible_screen`) VALUES
('Y' ,'2008-03-28 19:00:53' ,'AJM' ,'N' ,'ADD5 - Insert mutiple records' ,'ADD5' ,'This will allow several database records to be created from a single input screen.

Details of the parent table are passed down in $where.

This will use the \'insertMultiple\' method.' ,'Y');
