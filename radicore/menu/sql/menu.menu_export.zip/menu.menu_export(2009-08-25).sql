USE `menu`;

UPDATE `mnu_task` SET `revised_date`='2009-08-25 16:36:16' ,`revised_user`='AJM' ,`subsys_id`='MISC' WHERE task_id='batch_log(filedownload)';

UPDATE `mnu_task` SET `revised_date`='2009-08-25 16:36:30' ,`revised_user`='AJM' ,`subsys_id`='MISC' WHERE task_id='batch_log(filepicker)';
