DELETE FROM mnu_pattern WHERE pattern_id='POPUP';
DELETE FROM mnu_pattern WHERE pattern_id='TREE1POPUP';
DELETE FROM mnu_pattern WHERE pattern_id='TREE2POPUP';
