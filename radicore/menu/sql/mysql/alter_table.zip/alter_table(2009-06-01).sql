USE `menu`;

ALTER TABLE `mnu_user` ADD `user_timezone` VARCHAR( 40 ) NULL AFTER `party_id`;
