USE `menu`;

REPLACE INTO `mnu_control` (`created_date` ,`created_user` ,`field_id` ,`field_value` ,`record_id`) VALUES
('2008-10-05 14:53:39' ,'AJM' ,'LOGIN_TYPE' ,'USER' ,'SYSTEM');
