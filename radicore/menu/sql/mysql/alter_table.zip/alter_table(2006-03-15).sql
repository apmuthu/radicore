ALTER TABLE `mnu_user` ADD `email_addr` VARCHAR( 50 ) NULL AFTER `ip_address` ;
