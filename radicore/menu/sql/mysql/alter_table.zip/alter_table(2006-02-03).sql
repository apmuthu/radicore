ALTER TABLE `mnu_task` ADD `screen_refresh` SMALLINT UNSIGNED NULL AFTER `log_sql_query` ;
