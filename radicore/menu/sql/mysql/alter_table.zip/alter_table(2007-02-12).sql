ALTER TABLE `mnu_task` CHANGE `task_desc` `task_desc` VARCHAR( 80 ) NOT NULL;
ALTER TABLE `mnu_task` CHANGE `button_text` `button_text` VARCHAR( 80 ) NULL DEFAULT NULL;
ALTER TABLE `mnu_task` CHANGE `script_id` `script_id` VARCHAR( 80 ) NULL DEFAULT NULL;




