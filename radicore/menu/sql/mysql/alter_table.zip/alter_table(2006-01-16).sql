ALTER TABLE `mnu_task` ADD `log_sql_query` CHAR( 1 ) NULL AFTER `keep_data` ;

